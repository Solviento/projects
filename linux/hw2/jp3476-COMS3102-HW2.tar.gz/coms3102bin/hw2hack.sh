#!/bin/bash

source  /usr/bin/hello.coms3102


